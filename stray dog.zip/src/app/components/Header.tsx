import React from 'react';
import { PawPrint, MapPin, AlertCircle, Menu } from 'lucide-react';

export const Header: React.FC = () => {
  return (
    <header className="sticky top-0 z-50 w-full bg-white border-b border-gray-100 shadow-sm">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center">
            <PawPrint className="text-orange-600 w-6 h-6" />
          </div>
          <span className="font-bold text-xl tracking-tight text-gray-900">StreetPet Care</span>
        </div>
        
        <nav className="hidden md:flex items-center gap-8">
          <a href="#" className="text-gray-600 hover:text-orange-600 font-medium transition-colors">Home</a>
          <a href="#" className="text-gray-600 hover:text-orange-600 font-medium transition-colors">Nearby Feed</a>
          <a href="#" className="text-gray-600 hover:text-orange-600 font-medium transition-colors">How to Help</a>
        </nav>

        <div className="flex items-center gap-4">
          <button className="md:hidden p-2 text-gray-600">
            <Menu className="w-6 h-6" />
          </button>
          <button className="bg-orange-600 text-white px-5 py-2 rounded-full font-semibold hover:bg-orange-700 transition-all shadow-lg shadow-orange-200">
            Login
          </button>
        </div>
      </div>
    </header>
  );
};
