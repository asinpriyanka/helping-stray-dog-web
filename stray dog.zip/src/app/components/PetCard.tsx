import React from 'react';
import { MapPin, Clock, Heart, Share2, Info } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface PetCardProps {
  id: string;
  image: string;
  location: string;
  description: string;
  timeReported: string;
  status: 'Urgent' | 'Stable' | 'Helped';
}

export const PetCard: React.FC<PetCardProps> = ({ image, location, description, timeReported, status }) => {
  const statusColors = {
    Urgent: 'bg-red-100 text-red-700 border-red-200',
    Stable: 'bg-blue-100 text-blue-700 border-blue-200',
    Helped: 'bg-green-100 text-green-700 border-green-200',
  };

  return (
    <div className="bg-white rounded-3xl overflow-hidden border border-gray-100 shadow-sm hover:shadow-xl transition-all duration-300 group">
      <div className="relative h-64 overflow-hidden">
        <ImageWithFallback 
          src={image} 
          alt="Reported Pet" 
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
        />
        <div className="absolute top-4 left-4">
          <span className={`px-3 py-1 rounded-full text-xs font-bold border ${statusColors[status]}`}>
            {status}
          </span>
        </div>
      </div>
      
      <div className="p-5">
        <div className="flex items-center gap-2 text-gray-500 text-sm mb-3">
          <MapPin className="w-4 h-4 text-orange-500" />
          <span className="truncate">{location}</span>
        </div>
        
        <p className="text-gray-800 font-medium line-clamp-2 mb-4 leading-relaxed">
          {description}
        </p>
        
        <div className="flex items-center justify-between pt-4 border-t border-gray-50">
          <div className="flex items-center gap-1.5 text-gray-400 text-xs">
            <Clock className="w-3.5 h-3.5" />
            <span>{timeReported}</span>
          </div>
          
          <div className="flex gap-2">
            <button className="p-2 hover:bg-orange-50 rounded-full transition-colors text-gray-400 hover:text-orange-600">
              <Share2 className="w-5 h-5" />
            </button>
            <button className="bg-orange-600 text-white px-4 py-1.5 rounded-full text-sm font-semibold hover:bg-orange-700 transition-colors">
              Help
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
