import React, { useState } from 'react';
import { Header } from './components/Header';
import { PetCard } from './components/PetCard';
import { ReportModal } from './components/ReportModal';
import { Toaster } from 'sonner';
import { Plus, Search, Filter, Compass, Bell, Shield, Heart, PawPrint } from 'lucide-react';
import { motion } from 'motion/react';

const MOCK_REPORTS = [
  {
    id: '1',
    image: 'https://images.unsplash.com/photo-1691221679153-168621acfb4d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHJheSUyMGRvZyUyMHN0cmVldHxlbnwxfHx8fDE3NzAxOTUxMTZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    location: 'Central Avenue, Near Starbucks',
    description: 'Small brown puppy seen wandering alone. Looks very hungry and scared.',
    timeReported: '2 hours ago',
    status: 'Urgent' as const,
  },
  {
    id: '2',
    image: 'https://images.unsplash.com/photo-1643208411980-7d73e38cd668?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob21lbGVzcyUyMGRvZyUyMGh1bmdyeXxlbnwxfHx8fDE3NzAyNjk1MTB8MA&ixlib=rb-4.1.0&q=80&w=1080',
    location: 'Oak Street Park',
    description: 'Older dog with no collar. Seems calm but needs food and water.',
    timeReported: '5 hours ago',
    status: 'Stable' as const,
  },
  {
    id: '3',
    image: 'https://images.unsplash.com/photo-1677426304132-0e2782c2b8d4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHJheSUyMGNhdCUyMHN0cmVldCUyMGh1bmdyeXxlbnwxfHx8fDE3NzAyNjk1MTIs',
    location: '2nd Street Alleyway',
    description: 'Ginger cat spotted. Very thin. Left some kibble but needs a shelter.',
    timeReported: '1 day ago',
    status: 'Urgent' as const,
  },
];

export default function App() {
  const [reports, setReports] = useState(MOCK_REPORTS);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const handleNewReport = (data: any) => {
    const newReport = {
      id: Math.random().toString(36).substr(2, 9),
      image: 'https://images.unsplash.com/photo-1691221679153-168621acfb4d?auto=format&fit=crop&q=80',
      location: data.location,
      description: data.description,
      timeReported: 'Just now',
      status: 'Urgent' as const,
    };
    setReports([newReport, ...reports]);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Toaster position="top-center" richColors />
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="bg-orange-600 rounded-[2rem] p-8 md:p-12 mb-12 text-white relative overflow-hidden">
          <div className="relative z-10 max-w-2xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 leading-tight">
              See a stray in need? <br />
              <span className="text-orange-200">Help them find home.</span>
            </h1>
            <p className="text-orange-100 text-lg mb-8 opacity-90">
              Community-driven platform to report and assist stray animals in your neighborhood. 
              Together, we can ensure no pet goes hungry on the streets.
            </p>
            <div className="flex flex-wrap gap-4">
              <button 
                onClick={() => setIsModalOpen(true)}
                className="bg-white text-orange-600 px-8 py-4 rounded-2xl font-bold flex items-center gap-2 hover:bg-orange-50 transition-all shadow-xl"
              >
                <Plus className="w-5 h-5" />
                Report Sighting
              </button>
              <button className="bg-orange-700/50 backdrop-blur text-white px-8 py-4 rounded-2xl font-bold flex items-center gap-2 hover:bg-orange-700/70 transition-all">
                <Compass className="w-5 h-5" />
                Find Nearby
              </button>
            </div>
          </div>
          
          {/* Decorative circles */}
          <div className="absolute -top-24 -right-24 w-96 h-96 bg-orange-500 rounded-full opacity-50 blur-3xl" />
          <div className="absolute -bottom-24 -left-24 w-64 h-64 bg-orange-700 rounded-full opacity-30 blur-2xl" />
        </div>

        {/* Filters & Search */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="relative flex-grow">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input 
              type="text" 
              placeholder="Search by location or description..."
              className="w-full pl-12 pr-4 py-4 bg-white border border-gray-100 rounded-2xl shadow-sm focus:ring-2 focus:ring-orange-500 outline-none transition-all"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <button className="bg-white px-6 py-4 rounded-2xl border border-gray-100 shadow-sm flex items-center gap-2 font-semibold text-gray-700 hover:bg-gray-50 transition-all">
            <Filter className="w-5 h-5" />
            Filter
          </button>
        </div>

        {/* Features Row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="bg-white p-6 rounded-3xl border border-gray-100 flex items-start gap-4">
            <div className="w-12 h-12 bg-blue-100 rounded-2xl flex items-center justify-center flex-shrink-0">
              <Bell className="text-blue-600 w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-gray-900 mb-1">Instant Alerts</h3>
              <p className="text-gray-500 text-sm">Nearby volunteers get notified immediately when you post.</p>
            </div>
          </div>
          <div className="bg-white p-6 rounded-3xl border border-gray-100 flex items-start gap-4">
            <div className="w-12 h-12 bg-green-100 rounded-2xl flex items-center justify-center flex-shrink-0">
              <Shield className="text-green-600 w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-gray-900 mb-1">Safe Tracking</h3>
              <p className="text-gray-500 text-sm">Verified reports ensure the safety of both pets and humans.</p>
            </div>
          </div>
          <div className="bg-white p-6 rounded-3xl border border-gray-100 flex items-start gap-4">
            <div className="w-12 h-12 bg-pink-100 rounded-2xl flex items-center justify-center flex-shrink-0">
              <Heart className="text-pink-600 w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-gray-900 mb-1">Community Love</h3>
              <p className="text-gray-500 text-sm">Join thousands helping strays find food and shelter daily.</p>
            </div>
          </div>
        </div>

        {/* Feed Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {reports
            .filter(r => r.description.toLowerCase().includes(searchQuery.toLowerCase()) || r.location.toLowerCase().includes(searchQuery.toLowerCase()))
            .map((report) => (
            <motion.div
              layout
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              key={report.id}
            >
              <PetCard {...report} />
            </motion.div>
          ))}
        </div>

        {/* Empty State */}
        {reports.length === 0 && (
          <div className="text-center py-20">
            <p className="text-gray-400 text-lg italic">No sightings reported yet. Be the first to help!</p>
          </div>
        )}
      </main>

      <footer className="bg-white border-t border-gray-100 py-12">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <PawPrint className="text-orange-600 w-6 h-6" />
            <span className="font-bold text-xl text-gray-900">StreetPet Care</span>
          </div>
          <p className="text-gray-500 max-w-md mx-auto mb-8">
            Making the world a kinder place for our four-legged friends, one report at a time.
          </p>
          <div className="flex justify-center gap-6 text-gray-400 text-sm">
            <a href="#" className="hover:text-orange-600">Privacy Policy</a>
            <a href="#" className="hover:text-orange-600">Terms of Service</a>
            <a href="#" className="hover:text-orange-600">Contact Us</a>
          </div>
        </div>
      </footer>

      {/* Floating Action Button for Mobile */}
      <button 
        onClick={() => setIsModalOpen(true)}
        className="md:hidden fixed bottom-6 right-6 w-16 h-16 bg-orange-600 rounded-full shadow-2xl flex items-center justify-center text-white z-50 hover:scale-110 active:scale-95 transition-all"
      >
        <Plus className="w-8 h-8" />
      </button>

      <ReportModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        onSubmit={handleNewReport}
      />
    </div>
  );
}
