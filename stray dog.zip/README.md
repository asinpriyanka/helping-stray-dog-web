
  # Woman Safety Tracking App

  This is a code bundle for Woman Safety Tracking App. The original project is available at https://www.figma.com/design/BX5AYIZ229IkVHqHhHusWO/Woman-Safety-Tracking-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  